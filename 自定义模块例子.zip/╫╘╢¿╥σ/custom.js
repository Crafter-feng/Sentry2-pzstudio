Blockly.Python['test_block'] = function(block) {
    var pin = block.getFieldValue("PIN")
    return ["get(" + pin + ")",Blockly.Python.ORDER_ATOMIC];
};


Blockly.Blocks['test_block'] = {
    
    init: function() {
        this.jsonInit({
          "message0": "火焰传感器 %1 检测到火焰",
          "args0": [
              {
                  "type": "field_dropdown",
                  "name": "PIN",
                  "options": [
                      ["P14", '14'],
                      ["P1", '1'],
                      ["P2", '2'],
                      ["P5", '5'],
                      ["P8", '8'],
                      ["P11", '11'],
                      ["P12", '12'],
                      ["P13", '13'],
                      ["P15", '15'],
                  ]
              }
          ],
          "colour": "#2F4F4F",
          "category": Blockly.Categories.motion,
          "extensions": ["output_boolean"]
        });
      }
};